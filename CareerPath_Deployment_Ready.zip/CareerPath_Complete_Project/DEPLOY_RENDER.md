# Deploy CareerPath on Render

This package is configured as a single Render web service. The Docker build compiles the Vite React frontend and then serves it from FastAPI.

## Recommended database
Set `DATABASE_URL` to a managed PostgreSQL connection string for persistent attempts and feedback. If you leave it blank, the app falls back to SQLite inside the container; this is suitable only for a temporary demo because Render's default filesystem is ephemeral.

## Render steps
1. Put this project in a GitHub repository.
2. In Render, choose **New → Blueprint** and select the repository. Render will read `render.yaml`.
3. When prompted for `DATABASE_URL`, enter your PostgreSQL connection string. You can also leave it blank for a temporary demo.
4. Deploy.
5. Open the generated `https://<service>.onrender.com/` URL.
6. Check `https://<service>.onrender.com/api/health` and `/docs`.

## Local Docker test
```powershell
docker build -t careerpath .
docker run --rm -p 8000:8000 careerpath
```
Open http://localhost:8000

## Notes
- The frontend API URL is relative (`/api`), so no localhost URL is baked into production.
- The current project still has demo admin endpoints without authentication and a generated question bank. Those must be hardened/curated before treating the site as a production service.
