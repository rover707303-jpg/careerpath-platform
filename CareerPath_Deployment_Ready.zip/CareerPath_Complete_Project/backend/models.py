from sqlalchemy import String, Integer, Float, Boolean, Text, ForeignKey, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from datetime import datetime
from database import Base

class Career(Base):
    __tablename__='careers'
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120), unique=True)
    description: Mapped[str] = mapped_column(Text, default='')
    skills = relationship('Skill', back_populates='career', cascade='all, delete-orphan')

class Skill(Base):
    __tablename__='skills'
    id: Mapped[int] = mapped_column(primary_key=True)
    career_id: Mapped[int] = mapped_column(ForeignKey('careers.id'))
    name: Mapped[str] = mapped_column(String(120))
    required_level: Mapped[int] = mapped_column(Integer, default=4)
    career = relationship('Career', back_populates='skills')

class Question(Base):
    __tablename__='questions'
    id: Mapped[int] = mapped_column(primary_key=True)
    career_id: Mapped[int] = mapped_column(ForeignKey('careers.id'))
    skill_id: Mapped[int] = mapped_column(ForeignKey('skills.id'))
    difficulty: Mapped[str] = mapped_column(String(30))
    category: Mapped[str] = mapped_column(String(40))
    text: Mapped[str] = mapped_column(Text)
    options: Mapped[str] = mapped_column(Text)
    correct_index: Mapped[int] = mapped_column(Integer)
    explanation: Mapped[str] = mapped_column(Text)
    active: Mapped[bool] = mapped_column(Boolean, default=True)

class Attempt(Base):
    __tablename__='attempts'
    id: Mapped[int] = mapped_column(primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    career_id: Mapped[int] = mapped_column(ForeignKey('careers.id'))
    career_name: Mapped[str] = mapped_column(String(120))
    profile_json: Mapped[str] = mapped_column(Text, default='{}')
    total_questions: Mapped[int] = mapped_column(Integer)
    correct: Mapped[int] = mapped_column(Integer)
    score: Mapped[float] = mapped_column(Float)
    level: Mapped[str] = mapped_column(String(30))

class Answer(Base):
    __tablename__='answers'
    id: Mapped[int] = mapped_column(primary_key=True)
    attempt_id: Mapped[int] = mapped_column(ForeignKey('attempts.id'))
    question_id: Mapped[int] = mapped_column(ForeignKey('questions.id'))
    selected_index: Mapped[int] = mapped_column(Integer)
    is_correct: Mapped[bool] = mapped_column(Boolean)

class Feedback(Base):
    __tablename__='feedback'
    id: Mapped[int] = mapped_column(primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    name: Mapped[str] = mapped_column(String(120), default='Guest')
    email: Mapped[str] = mapped_column(String(200), default='')
    message: Mapped[str] = mapped_column(Text)
    rating: Mapped[int] = mapped_column(Integer, default=5)
    status: Mapped[str] = mapped_column(String(30), default='new')
