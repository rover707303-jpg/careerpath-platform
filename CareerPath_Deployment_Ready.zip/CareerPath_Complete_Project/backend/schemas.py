from pydantic import BaseModel, Field
from typing import Optional

class AnswerIn(BaseModel):
    question_id: int
    selected_index: int

class AttemptIn(BaseModel):
    career_id: int
    profile: dict = {}
    answers: list[AnswerIn]

class FeedbackIn(BaseModel):
    name: str = 'Guest'
    email: str = ''
    message: str = Field(min_length=3)
    rating: int = Field(default=5, ge=1, le=5)
