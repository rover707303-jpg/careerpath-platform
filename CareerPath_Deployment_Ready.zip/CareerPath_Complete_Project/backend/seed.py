from database import Base, engine, SessionLocal
from models import Career, Skill, Question
import json

CAREERS = {
'Banking & Accounting':['Accounting Fundamentals','Financial Analysis','Excel','Banking Operations','Communication'],
'Management':['Leadership','Operations Management','Decision Making','Business Communication','Team Management'],
'Full Stack Developer':['HTML/CSS','JavaScript','React','Backend APIs','SQL'],
'Web Development':['HTML/CSS','JavaScript','Responsive Design','Web APIs','Web Security'],
'Software Development':['Programming','Data Structures','Algorithms','Git','Software Design'],
'Data Scientist':['Python','Statistics','Machine Learning','SQL','Data Visualization'],
'Data Analyst':['Excel','SQL','Statistics','Power BI/Tableau','Data Visualization'],
'AI / NLP Engineer':['Python','Machine Learning','NLP','Deep Learning','APIs'],
'Project Manager':['Project Planning','Agile/Scrum','Risk Management','Stakeholder Management','Communication'],
'Business Analyst':['Requirements Analysis','SQL','Excel','Process Modeling','Communication'],
'Cybersecurity':['Networking','Security Fundamentals','Linux','Threat Analysis','Incident Response'],
'Cloud Engineer':['Cloud Fundamentals','Linux','Networking','Docker','Cloud Security'],
'QA / Software Tester':['Testing Fundamentals','Test Cases','Automation','API Testing','Bug Reporting'],
'Mobile App Developer':['Programming','UI Development','APIs','Mobile Architecture','Testing'],
'UI/UX Designer':['UX Research','Wireframing','Visual Design','Prototyping','Usability Testing']}

DESCRIPTIONS = {
'Data Scientist':'Use statistics, programming and machine learning to turn data into decisions.',
'Data Analyst':'Analyze data, build dashboards and communicate actionable insights.',
'Full Stack Developer':'Build complete web products across frontend, backend and databases.',
'Project Manager':'Plan, coordinate and deliver projects while managing scope, risk and stakeholders.'}

TEMPLATES = [
('Technical MCQ','Which concept is most directly related to {skill}?',['Version control','Unrelated concept','Manual paperwork','None of these'],0),
('Scenario','A real project needs strong {skill}. What is the best first action?',['Clarify the requirement and define the expected outcome','Skip planning','Guess the requirement','Wait until the end'],0),
('HR / Workplace','Which behavior best demonstrates professional {skill}?',['Consistent practice, evidence and clear communication','Avoid feedback','Hide mistakes','Ignore team context'],0),
('Practical','A beginner is improving {skill}. Which approach is most effective?',['Build small tasks and review the result','Memorize without practice','Avoid examples','Only read headlines'],0),
('Technical MCQ','When applying {skill}, what should be prioritized?',['Correctness, context and maintainability','Speed at any cost','Complexity for its own sake','No validation'],0),
('Scenario','A result involving {skill} looks wrong. What should you do?',['Validate inputs, assumptions and output','Immediately publish it','Delete the work','Ignore the issue'],0),
('Communication','How should you explain a {skill} decision to a non-technical stakeholder?',['Use clear language, evidence and the impact','Use unexplained jargon','Avoid the reason','Give no conclusion'],0),
('Problem Solving','You face an unfamiliar {skill} problem. What is the strongest response?',['Break it down, research, test and iterate','Guess once and stop','Avoid testing','Copy blindly'],0),
('Advanced','Which principle makes {skill} work more reliable?',['Validation and measurable outcomes','No documentation','No testing','Unclear ownership'],0),
('Code / Output','A small exercise uses {skill}. What should you check before trusting its output?',['Inputs, logic and expected output','Only the screen color','File name only','Nothing'],0)
]

def build_questions():
    Base.metadata.create_all(engine)
    db=SessionLocal()
    if db.query(Career).count():
        db.close(); return
    for cname, skills in CAREERS.items():
        c=Career(name=cname, description=DESCRIPTIONS.get(cname,'Explore the skills, assessment and career roadmap for '+cname+'.'))
        db.add(c); db.flush()
        for sname in skills:
            s=Skill(career_id=c.id,name=sname,required_level=4)
            db.add(s); db.flush()
            qid=0
            for difficulty in ['Beginner','Intermediate','Advanced']:
                for n in range(10):
                    category,text,opts,correct=TEMPLATES[(n)%len(TEMPLATES)]
                    # vary option order slightly while retaining a known answer
                    q=Question(career_id=c.id,skill_id=s.id,difficulty=difficulty,category=category,
                        text=text.format(skill=sname)+f' (Question {n+1} of 10 — {difficulty})',
                        options=json.dumps(opts),correct_index=correct,
                        explanation=f'This answer is preferred because it applies a sound {sname} practice: define the context, validate the work, and communicate the result.')
                    db.add(q)
    db.commit(); db.close()

if __name__=='__main__':
    build_questions(); print('Database seeded.')
