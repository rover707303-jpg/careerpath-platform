from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pathlib import Path
import os
from sqlalchemy.orm import Session
from sqlalchemy import func
from database import Base, engine, get_db
from models import Career, Skill, Question, Attempt, Answer, Feedback
from schemas import AttemptIn, FeedbackIn
import json
try:
    from seed import build_questions
except ImportError:
    build_questions = None

Base.metadata.create_all(engine)
if build_questions is not None:
    try:
        build_questions()
    except Exception as exc:
        print(f'Database seed skipped: {exc}')
app=FastAPI(title='CareerPath API', version='1.0.0')
origins=[x.strip() for x in os.getenv('CORS_ORIGINS','').split(',') if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins or ['*'], allow_credentials=bool(origins), allow_methods=['*'], allow_headers=['*'])

@app.get('/')
def root():
    index=Path(__file__).parent/'static'/'index.html'
    if index.exists(): return FileResponse(index)
    return {'service':'CareerPath','status':'ok','docs':'/docs'}

@app.get('/api/health')
def health(): return {'status':'ok','service':'CareerPath API'}

@app.get('/api/careers')
def careers(db:Session=Depends(get_db)):
    return [{'id':c.id,'name':c.name,'description':c.description,'skills':[{'id':s.id,'name':s.name,'required_level':s.required_level} for s in c.skills]} for c in db.query(Career).all()]

@app.get('/api/careers/{career_id}/questions')
def questions(career_id:int, skill_ids:str='', difficulty:str='Beginner', limit:int=30, db:Session=Depends(get_db)):
    q=db.query(Question).filter(Question.career_id==career_id,Question.difficulty==difficulty,Question.active==True)
    if skill_ids:
        ids=[int(x) for x in skill_ids.split(',') if x.isdigit()]
        if ids:q=q.filter(Question.skill_id.in_(ids))
    rows=q.limit(limit).all()
    return [{'id':x.id,'skill_id':x.skill_id,'difficulty':x.difficulty,'category':x.category,'text':x.text,'options':json.loads(x.options)} for x in rows]

@app.post('/api/attempts')
def submit_attempt(data:AttemptIn, db:Session=Depends(get_db)):
    career=db.get(Career,data.career_id)
    if not career: raise HTTPException(404,'Career not found')
    qs={q.id:q for q in db.query(Question).filter(Question.id.in_([a.question_id for a in data.answers])).all()}
    correct=0; review=[]
    attempt=Attempt(career_id=career.id,career_name=career.name,profile_json=json.dumps(data.profile),total_questions=len(data.answers),correct=0,score=0,level='Needs Work')
    db.add(attempt); db.flush()
    for a in data.answers:
        q=qs.get(a.question_id)
        if not q: continue
        ok=a.selected_index==q.correct_index
        correct += int(ok)
        db.add(Answer(attempt_id=attempt.id,question_id=q.id,selected_index=a.selected_index,is_correct=ok))
        review.append({'question_id':q.id,'skill_id':q.skill_id,'text':q.text,'options':json.loads(q.options),'selected_index':a.selected_index,'correct_index':q.correct_index,'is_correct':ok,'explanation':q.explanation})
    score=round((correct/max(1,len(data.answers)))*100,1)
    level='Advanced' if score>=85 else 'Intermediate' if score>=65 else 'Beginner' if score>=45 else 'Needs Work'
    attempt.correct=correct; attempt.score=score; attempt.level=level
    db.commit()
    return {'attempt_id':attempt.id,'score':score,'correct':correct,'total':len(data.answers),'level':level,'review':review}

@app.get('/api/attempts')
def attempts(db:Session=Depends(get_db)):
    rows=db.query(Attempt).order_by(Attempt.created_at.asc()).all()
    return [{'id':a.id,'date':a.created_at.isoformat(),'career':a.career_name,'score':a.score,'level':a.level,'correct':a.correct,'total':a.total_questions} for a in rows]

@app.get('/api/attempts/{attempt_id}')
def attempt_detail(attempt_id:int,db:Session=Depends(get_db)):
    a=db.get(Attempt,attempt_id)
    if not a: raise HTTPException(404,'Attempt not found')
    answers=db.query(Answer).filter(Answer.attempt_id==attempt_id).all()
    out=[]
    for x in answers:
        q=db.get(Question,x.question_id)
        out.append({'question_id':q.id,'text':q.text,'options':json.loads(q.options),'selected_index':x.selected_index,'correct_index':q.correct_index,'is_correct':x.is_correct,'explanation':q.explanation,'skill_id':q.skill_id})
    return {'id':a.id,'career':a.career_name,'score':a.score,'level':a.level,'review':out}

@app.get('/api/roadmap/{career_id}')
def roadmap(career_id:int,db:Session=Depends(get_db)):
    c=db.get(Career,career_id)
    if not c: raise HTTPException(404,'Career not found')
    skills=[s.name for s in c.skills]
    weeks=[]
    for i in range(4):
        s=skills[i%len(skills)]
        weeks.append({'week':i+1,'skill':s,'topic':f'{s} fundamentals and practical application','activity':'Learn → practice → mini project → self-check','time':'60–90 min/day','resources':['W3Schools','Great Learning','YouTube']})
    return {'career':c.name,'weeks':weeks}

@app.post('/api/feedback')
def feedback(data:FeedbackIn,db:Session=Depends(get_db)):
    f=Feedback(**data.model_dump()); db.add(f); db.commit(); db.refresh(f); return {'id':f.id,'status':'received'}

@app.get('/api/admin/summary')
def admin_summary(db:Session=Depends(get_db)):
    return {'users':db.query(Attempt).count(),'attempts':db.query(Attempt).count(),'feedback_new':db.query(Feedback).filter(Feedback.status=='new').count(),'avg_score':round(db.query(func.avg(Attempt.score)).scalar() or 0,1),'careers':db.query(Career).count(),'questions':db.query(Question).count()}

@app.get('/api/admin/feedback')
def admin_feedback(db:Session=Depends(get_db)):
    return [{'id':f.id,'date':f.created_at.isoformat(),'name':f.name,'email':f.email,'message':f.message,'rating':f.rating,'status':f.status} for f in db.query(Feedback).order_by(Feedback.created_at.desc()).all()]

@app.get('/api/admin/questions')
def admin_questions(db:Session=Depends(get_db)):
    return [{'id':q.id,'career_id':q.career_id,'skill_id':q.skill_id,'difficulty':q.difficulty,'category':q.category,'text':q.text,'active':q.active} for q in db.query(Question).limit(500).all()]


# Serve the Vite production build when deployed as a single Render service.
_static_dir=Path(__file__).parent/'static'
if _static_dir.exists():
    app.mount('/assets', StaticFiles(directory=_static_dir/'assets'), name='assets')
