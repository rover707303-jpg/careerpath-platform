# CareerPath — Career Aspirance & Skill Gap Analysis Platform

A complete full-stack starter implementation of the project described in the specification.

## Included
- React + Vite frontend
- FastAPI backend
- SQLite database by default; PostgreSQL-ready via DATABASE_URL
- 15 career domains
- Career-specific skills
- 3 difficulty levels
- 30-question assessment per selected skill (generated from a reusable bank structure)
- Technical, HR/workplace, soft-skill and scenario questions
- Results, correct/incorrect explanations, skill-gap analysis and priorities
- Attempt history and progress data
- 4-week personalized roadmap and resources
- Feedback storage
- Admin dashboard and question/domain/skill management APIs
- AI Career Guide and voice Mock Interview extension points
- Guest assessment flow; authentication-ready API structure

## Run locally

### Backend (Windows PowerShell)
```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python seed.py
uvicorn main:app --reload --port 8000
```

### Frontend
Open another terminal:
```powershell
cd frontend
npm install
npm run dev
```

Open http://localhost:5173

Backend API docs: http://localhost:8000/docs

## Optional PostgreSQL
Set `DATABASE_URL` before starting the backend, for example:
`postgresql+psycopg://user:password@localhost:5432/careerpath`

## Demo admin
Username: `admin`
Password: `admin123`

Change this before deployment.

## Production notes
- Replace demo admin authentication with hashed passwords + JWT/session auth.
- Add CSRF/CORS restrictions, rate limiting, audit logs and HTTPS.
- Use PostgreSQL in production.
- Add a real AI provider only after setting an API key server-side.
- Voice mock interview requires browser microphone permission, speech-to-text and text-to-speech services.
- The included question generator gives a broad working bank structure; review and curate questions with domain experts before claiming psychometric or 99% accuracy.


## Public deployment (Render)

This version includes a production Dockerfile and `render.yaml`. The Docker image builds the React/Vite frontend and serves it from the FastAPI service, so the public site uses one URL.

1. Upload/push the project to GitHub.
2. In Render, select **New → Blueprint** and connect the repository.
3. Render reads `render.yaml` and deploys the service.
4. For persistent attempts/feedback, provide a PostgreSQL `DATABASE_URL`; leaving it blank uses SQLite temporarily.
5. Open the generated `onrender.com` URL.

See `DEPLOY_RENDER.md` for the deployment checklist.
